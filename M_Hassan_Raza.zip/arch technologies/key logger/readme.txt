# Keylogger Script - Task 01

**Company:** Arch Technologies

**Internship Task:** 01

## Overview

This repository contains a basic Python-based keylogger designed to capture and record keyboard inputs. This project was developed as part of an introductory cybersecurity task to understand how input listeners function and how data can be logged to a local file system.

## Features

* **Real-time Capture:** Utilizes a keyboard listener to detect keystrokes as they happen.
* **Data Formatting:** Automatically cleans the input string to remove unnecessary characters (like single quotes) for better readability.
* **Persistent Storage:** Appends every keystroke to a local text file (`keys.txt`) immediately.

## Prerequisites

Before running the script, ensure you have Python installed and the necessary library:

1. **Python 3.x**
2. **pynput library:** This library allows you to control and monitor input devices.
```bash
pip install pynput

```



## Usage

1. **Clone the script** to your local machine.
2. **Run the script** via your terminal or IDE:
```bash
python keylogger.py

```


3. **To stop logging:** Terminate the process in your terminal (usually `Ctrl + C`).
4. **Review logs:** Open the generated `keys.txt` file in the same directory to view the captured keystrokes.

## Code Structure

* `from pynput.keyboard import Listener`: Imports the necessary class to monitor the keyboard.
* `log_key(key)`: A callback function that triggers on every "on_press" event. It formats the key and writes it to the file.
* `with Listener(...) as listener`: The context manager that keeps the script running and listening for events.

---

## ⚠️ Ethical & Legal Disclaimer

**For Educational Purposes Only.** This software is developed for internship training and authorized security testing. The unauthorized use of a keylogger on a computer you do not own or have explicit permission to monitor is **illegal and unethical**. Arch Technologies and the developer do not condone the use of this tool for malicious activities.

---
