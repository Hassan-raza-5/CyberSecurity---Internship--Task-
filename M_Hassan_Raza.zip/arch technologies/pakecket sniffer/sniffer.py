import scapy.all as scapy

def sniff(interface):
    print(f"[*] Sniffing started on {interface}... Press Ctrl+C to stop.")
    scapy.sniff(iface=interface, store=False, prn=process_packet)

def process_packet(packet):
    if packet.haslayer(scapy.IP):
        src_ip = packet[scapy.IP].src
        dst_ip = packet[scapy.IP].dst

        if packet.haslayer(scapy.TCP):
            protocol = "TCP"
            sport = packet[scapy.TCP].sport
            dport = packet[scapy.TCP].dport
        elif packet.haslayer(scapy.UDP):
            protocol = "UDP"
            sport = packet[scapy.UDP].sport
            dport = packet[scapy.UDP].dport
        else:
            protocol = "Other"
            sport = "-"
            dport = "-"

        print(f"[+] {src_ip} -> {dst_ip} | {protocol} | {sport} -> {dport}")

sniff("Wi-Fi")
