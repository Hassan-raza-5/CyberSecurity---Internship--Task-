# Network Packet Sniffer - Task 02

**Company:** Arch Technologies

**Internship Task:** 02

## Overview

This script is a fundamental network analysis tool designed to capture and inspect real-time IP traffic. By leveraging the `scapy` library, the sniffer intercepts packets flowing through a specified network interface and extracts key metadata such as source/destination IP addresses, protocols (TCP/UDP), and port numbers.

## Features

* **Protocol Identification:** Automatically detects and labels TCP, UDP, and other IP-based protocols.
* **Port Mapping:** Extracts source and destination ports for transport layer analysis.
* **Live Console Output:** Prints packet details to the terminal in a human-readable format for immediate monitoring.
* **Lightweight Execution:** Uses the `store=False` parameter to process packets in memory without bloating system resources.

## Prerequisites

Before running the sniffer, ensure you have the following:

1. **Python 3.x**
2. **Scapy Library:**
```bash
pip install scapy

```


3. **Administrative Privileges:** Network sniffing requires "Promiscuous Mode" access. You must run the script as **Administrator** (Windows) or using **sudo** (Linux/macOS).
4. **Npcap/Libpcap:** * **Windows:** Ensure [Npcap](https://nmap.org/npcap/) is installed (often included with Wireshark).
* **Linux:** Ensure `libpcap` is installed.



## Usage

1. **Identify your Interface:** Open your terminal and find your active network interface name (e.g., `Wi-Fi`, `eth0`, `en0`).
2. **Update the Script:** If your interface is not named "Wi-Fi", update the last line of `sniffer.py`:
```python
sniff("Your-Interface-Name")

```


3. **Run the Script:**
```bash
# Windows (Run PowerShell/CMD as Admin)
python sniffer.py

# Linux/macOS
sudo python3 sniffer.py

```



## Code Logic

* **`sniff(interface)`:** Initializes the capture loop on the specified hardware interface.
* **`process_packet(packet)`:** The core logic function that parses each packet:
* Checks for the **IP Layer** to get addresses.
* Checks for **TCP/UDP Layers** to extract port numbers.


* **`prn=process_packet`:** A callback argument that tells Scapy to run the `process_packet` function for every packet it catches.

---

## ⚠️ Ethical & Legal Disclaimer

**For Educational Use Only.** This tool is intended for internship training and authorized network troubleshooting. Sniffing network traffic on hardware or networks you do not own—or without explicit permission—is a violation of privacy laws and could lead to legal consequences. Always use this tool within a controlled lab environment or authorized infrastructure.

---